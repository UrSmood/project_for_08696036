import sys
import pymysql
from PyQt5.QtWidgets import QApplication, QWidget, QLabel, QLineEdit, QPushButton, QMessageBox
from PyQt5.QtGui import QFont
from PyQt5.QtCore import Qt
import qdarkstyle
from utils import MySQLUtils
from view import LoginView

class RegistrationPage(QWidget):
    """
    注册窗口
    """
    def __init__(self):
        super().__init__()
        # 设置窗口标题
        self.setWindowTitle("注册页面")
        # 设置窗口位置和大小
        self.setGeometry(100, 100, 400, 300)
        # 设置窗口固定大小
        self.setFixedSize(400, 300)
        # 使用qdarkstyle样式
        self.setStyleSheet(qdarkstyle.load_stylesheet_pyqt5())

        # 创建标题标签
        self.title_label = QLabel(self)
        # 设置标题文本
        self.title_label.setText("注册")
        # 设置字体
        self.title_label.setFont(QFont("Arial", 20))
        # 设置文本居中对齐
        self.title_label.setAlignment(Qt.AlignCenter)
        # 设置位置和大小
        self.title_label.setGeometry(0, 10, 400, 30)

        # 创建用户名标签
        self.username_label = QLabel(self)
        # 设置用户名文本
        self.username_label.setText("用户名:")
        # 设置字体
        self.username_label.setFont(QFont("Arial", 12))
        # 设置位置和大小
        self.username_label.setGeometry(50, 70, 100, 30)

        # 创建用户名输入框
        self.username_input = QLineEdit(self)
        # 设置位置和大小
        self.username_input.setGeometry(150, 70, 200, 30)

        # 创建密码标签
        self.password_label = QLabel(self)
        # 设置密码文本
        self.password_label.setText("密码:")
        # 设置字体
        self.password_label.setFont(QFont("Arial", 12))
        # 设置位置和大小
        self.password_label.setGeometry(50, 120, 100, 30)
        # 创建密码输入框
        self.password_input = QLineEdit(self)
        # 设置位置和大小
        self.password_input.setGeometry(150, 120, 200, 30)
        # 设置密码输入模式为密码
        self.password_input.setEchoMode(QLineEdit.Password)

        # 创建注册按钮
        self.register_button = QPushButton(self)
        # 设置按钮文本
        self.register_button.setText("注册")
        # 设置位置和大小
        self.register_button.setGeometry(100, 220, 100, 30)
        # 连接注册按钮的点击事件
        self.register_button.clicked.connect(self.register)

        # 创建登录按钮
        self.login_button = QPushButton(self)
        # 设置按钮文本
        self.login_button.setText("去登录")
        # 设置位置和大小
        self.login_button.setGeometry(200, 220, 100, 30)
        # 连接登录按钮的点击事件
        self.login_button.clicked.connect(self.login)

    # 注册按钮点击事件
    def register(self):
        # 获取用户名输入框的文本
        username = self.username_input.text()
        # 获取密码输入框的文本
        password = self.password_input.text()

        # 如果用户名或密码为空
        if not username or not password:
            QMessageBox.warning(self, "注册失败", "用户名和密码不能为空！")
            return

        # 获取数据库连接
        connection = MySQLUtils.get_connection()
        try:
            with connection.cursor() as cursor:
                sql = "SELECT * FROM `user` WHERE `username` = %s"
                cursor.execute(sql, (username,))
                result = cursor.fetchone()
                if result:
                    QMessageBox.warning(self, "注册失败", "用户名已存在！")
                else:
                    sql = "INSERT INTO `user` (`username`, `password`) VALUES (%s, %s)"
                    cursor.execute(sql, (username, password))
                    connection.commit()
                    QMessageBox.information(self, "注册成功", "注册成功！")
                    # 清空用户名输入框
                    self.username_input.clear()
                    self.password_input.clear()
                    self.hide()
                    self.loginView = LoginView.LoginPage()
                    self.loginView.show()


        except pymysql.Error as e:
            QMessageBox.warning(self, "注册失败", f"注册失败：{str(e)}")
        finally:
            connection.close()

    def login(self):
        self.hide()
        self.loginView = LoginView.LoginPage()
        self.loginView.show()


if __name__ == '__main__':
    app = QApplication(sys.argv)
    app.setStyleSheet(qdarkstyle.load_stylesheet_pyqt5())

    window = RegistrationPage()
    window.show()

    sys.exit(app.exec_())
