import sys
from PyQt5.QtWidgets import QApplication, QMainWindow, QWidget, QLabel, QVBoxLayout, QPushButton, QMessageBox, QAction, \
    QMenu
from PyQt5.QtGui import QFont
from PyQt5.QtCore import Qt
from view import FaceCapView
import cv2
import face_recognition
from PyQt5.QtCore import Qt, QTimer
from PyQt5.QtGui import QImage, QPixmap
from PIL import Image
from face_recognize import Face
from utils import MySQLUtils
import time


class Product:
    def __init__(self, name, price, description):
        self.name = name
        self.price = price
        self.description = description


class ProductWindow(QWidget):
    def __init__(self, product, user_id):
        super().__init__()
        self.user_id = user_id
        self.setWindowTitle("商品详情")
        self.setGeometry(100, 100, 400, 300)
        self.product = product
        layout = QVBoxLayout()

        name_label = QLabel(self)
        name_label.setText("商品名称: " + product.name)
        layout.addWidget(name_label)

        price_label = QLabel(self)
        price_label.setText("价格: $" + str(product.price))
        layout.addWidget(price_label)

        description_label = QLabel(self)
        description_label.setText("描述: " + product.description)
        layout.addWidget(description_label)

        purchase_button = QPushButton(self)
        purchase_button.setText("购买")
        purchase_button.clicked.connect(self.purchase_product)
        layout.addWidget(purchase_button)

        self.setLayout(layout)

    def purchase_product(self):
        reg = Face()
        # 根据用户编号查询用户的所有照片路径

        # 建立数据库连接
        connection = MySQLUtils.get_connection()
        image_arr = []
        try:
            # 创建游标对象
            cursor = connection.cursor()

            # 执行查询语句
            query = "SELECT path FROM image WHERE userId = %s"
            cursor.execute(query, (self.user_id,))

            # 获取查询结果
            results = cursor.fetchall()
            for result in results:
                # 获取当前用户的所有路径
                path = result[0]
                print(path)
                image_arr.append(path)

        finally:
            # 关闭游标和数据库连接
            cursor.close()
            connection.close()

        # 特征列表
        embs = []
        for img in image_arr:
            emb_true = reg.face_embeding(img)
            embs.append(emb_true)

        for i in embs:
            print(i.shape)

        cap = cv2.VideoCapture(0)
        flag = True
        while flag:

            ret, frame = cap.read()

            cv2.imshow("Frame", frame)
            try:
                emb = reg.face_embeding_frame(frame)
                for emb_true in embs:
                    score = reg.get_sim(emb_true, emb)

                    if score > 0.6:
                        print("对")
                        flag = False
                        time.sleep(3)
                        QMessageBox.information(self, "系统提示", f"人脸比对成功，你需要支付的金额为：{self.product.price}")
                        # 关闭所有打开的窗口
                        cv2.destroyAllWindows()

                        break
            except:
                pass

            # 如果按下“q”键，则退出循环
            if cv2.waitKey(1) & 0xFF == ord('q'):
                time.sleep(3)
                # 关闭所有打开的窗口
                cv2.destroyAllWindows()
                break


class CameraWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.initUI()

    def initUI(self):
        self.setWindowTitle("摄像头实时信息")
        self.setGeometry(200, 200, 640, 480)

        # 创建用于显示图像的 QLabel
        self.image_label = QLabel(self)
        self.image_label.setAlignment(Qt.AlignCenter)

        # 创建垂直布局，并将 QLabel 添加到布局中
        layout = QVBoxLayout(self)
        layout.addWidget(self.image_label)

        # 创建定时器，用于定时更新图像
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.update_image)
        self.timer.start(30)  # 每30毫秒更新一次图像

        # 打开摄像头
        self.video_capture = cv2.VideoCapture(0)

    def update_image(self):
        # 捕捉每一帧图像
        ret, frame = self.video_capture.read()

        # 将图像转换为 QImage 格式
        height, width, channel = frame.shape
        qimage = QImage(frame.data, width, height, frame.strides[0], QImage.Format_RGB888)

        # 将 QImage 转换为 QPixmap，并显示在 QLabel 上
        pixmap = QPixmap.fromImage(qimage)
        self.image_label.setPixmap(pixmap)

    def closeEvent(self, event):
        # 关闭窗口时释放摄像头
        self.video_capture.release()


class MainWindow(QMainWindow):
    def __init__(self, uId):
        super().__init__()
        self.user_id = uId
        print("用户登录，编号是")
        print(self.user_id)
        self.setWindowTitle("购买商品商城")
        self.setGeometry(100, 100, 400, 300)

        self.products = [
            Product("商品1", 10, "这是商品1的描述"),
            Product("商品2", 20, "这是商品2的描述"),
            Product("商品3", 30, "这是商品3的描述")
        ]

        self.central_widget = QWidget(self)
        self.setCentralWidget(self.central_widget)

        layout = QVBoxLayout()

        for product in self.products:
            product_button = QPushButton(self)
            product_button.setText(product.name)
            product_button.clicked.connect(lambda _, p=product: self.show_product_window(p))
            layout.addWidget(product_button)

        self.central_widget.setLayout(layout)

        self.create_menu()

    def show_product_window(self, product):
        """展示窗口详细页面"""
        self.product_window = ProductWindow(product, self.user_id)
        self.product_window.show()

    def create_menu(self):
        menu_bar = self.menuBar()

        face_menu = QMenu("人脸信息", self)
        menu_bar.addMenu(face_menu)

        enter_face_action = QAction("录入人脸信息", self)
        enter_face_action.triggered.connect(self.enter_face_info)
        face_menu.addAction(enter_face_action)

    def enter_face_info(self):
        """
        实例化录入人脸窗口
        :return:
        """
        self.faceCapView = FaceCapView.FaceRecognitionWindow(self.user_id)
        self.faceCapView.show()


if __name__ == '__main__':
    app = QApplication(sys.argv)

    window = MainWindow()
    window.show()

    sys.exit(app.exec_())
