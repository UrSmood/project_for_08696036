import sys
import pymysql
from PyQt5.QtWidgets import QApplication, QWidget, QLabel, QLineEdit, QPushButton, QMessageBox
from PyQt5.QtGui import QFont
from PyQt5.QtCore import Qt
import qdarkstyle
from view import RegisterView
from utils import MySQLUtils
from view import MainView


class LoginPage(QWidget):
    """
    登录窗口
    """

    def __init__(self):
        super().__init__()
        # 设置窗口标题
        self.setWindowTitle("登录页面")
        # 设置窗口位置和大小
        self.setGeometry(100, 100, 400, 200)
        # 固定窗口大小
        self.setFixedSize(400, 200)
        # 使用qdarkstyle样式
        self.setStyleSheet(qdarkstyle.load_stylesheet_pyqt5())

        # 创建标题标签
        self.title_label = QLabel(self)
        # 设置标题文本
        self.title_label.setText("登录")
        # 设置标题字体
        self.title_label.setFont(QFont("Arial", 20))
        # 居中对齐
        self.title_label.setAlignment(Qt.AlignCenter)
        # 设置标题位置和大小
        self.title_label.setGeometry(0, 10, 400, 30)

        # 创建用户名标签
        self.username_label = QLabel(self)
        # 设置用户名文本
        self.username_label.setText("用户名:")
        # 设置用户名字体
        self.username_label.setFont(QFont("Arial", 12))
        # 设置用户名位置和大小
        self.username_label.setGeometry(50, 50, 100, 30)

        # 创建用户名输入框
        self.username_input = QLineEdit(self)
        # 设置用户名输入框位置和大小
        self.username_input.setGeometry(150, 50, 200, 30)

        # 创建密码标签
        self.password_label = QLabel(self)
        # 设置密码文本
        self.password_label.setText("密码:")
        # 设置密码字体
        self.password_label.setFont(QFont("Arial", 12))
        # 设置密码位置和大小
        self.password_label.setGeometry(50, 100, 100, 30)

        # 创建密码输入框
        self.password_input = QLineEdit(self)
        # 设置密码输入框位置和大小
        self.password_input.setGeometry(150, 100, 200, 30)
        # 设置密码输入框为密码模式
        self.password_input.setEchoMode(QLineEdit.Password)

        # 创建登录按钮
        self.login_button = QPushButton(self)
        # 设置登录按钮文本
        self.login_button.setText("登录")
        # 设置登录按钮位置和大小
        self.login_button.setGeometry(150, 150, 100, 30)
        # 点击登录按钮连接登录方法
        self.login_button.clicked.connect(self.login)

        # 创建注册按钮
        self.register_button = QPushButton(self)
        # 设置注册按钮文本
        self.register_button.setText("注册")
        # 设置注册按钮位置和大小
        self.register_button.setGeometry(260, 150, 100, 30)
        # 点击注册按钮连接打开注册窗口方法
        self.register_button.clicked.connect(self.open_registration)

    def login(self):
        # 获取用户名输入框文本
        username = self.username_input.text()
        # 获取密码输入框文本
        password = self.password_input.text()

        if not username or not password:
            QMessageBox.warning(self, "登录失败", "用户名和密码不能为空！")
            return

        # 获取数据库连接
        connection = MySQLUtils.get_connection()
        try:
            with connection.cursor() as cursor:
                sql = "SELECT id FROM `user` WHERE `username` = %s AND `password` = %s"
                cursor.execute(sql, (username, password))
                result = cursor.fetchone()
                if result:
                    user_id = result[0]  # 获取用户编号ID
                    QMessageBox.information(self, "登录成功", "登录成功！")
                    self.mainView = MainView.MainWindow(user_id)  # 将用户编号ID传递给主窗口
                    self.mainView.show()
                    self.close()
                else:
                    QMessageBox.warning(self, "登录失败", "用户名或密码不正确！")
        except pymysql.Error as e:
            QMessageBox.warning(self, "登录失败", f"登录失败：{str(e)}")
        finally:
            connection.close()

    def open_registration(self):
        # 创建注册窗口
        self.registration_window = RegisterView.RegistrationPage()
        self.registration_window.show()
        self.hide()


if __name__ == '__main__':
    app = QApplication(sys.argv)
    app.setStyleSheet(qdarkstyle.load_stylesheet_pyqt5())

    login_window = LoginPage()
    login_window.show()

    sys.exit(app.exec_())
