from model import Backbone
import torch
from PIL import Image
from mtcnn import MTCNN
from torchvision.transforms import Compose, ToTensor, Normalize


mtcnn = MTCNN()

class FacialRecognition:
    class FaceRecognizer:
        def __init__(self, mtcnn_model_path, recognition_model_path, device='cpu'):
            self.device = device
            self.mtcnn = MTCNN()
            self.model = Backbone(num_layers=50, drop_ratio=0.6, mode='ir_se')
            self.model.load_state_dict(torch.load(recognition_model_path, map_location=torch.device(device)))
            self.model.eval()
            self.model.to(device)
            self.transforms = Compose([
                ToTensor(),
                Normalize([0.5, 0.5, 0.5], [0.5, 0.5, 0.5])
            ])

        def get_img(self, img_path):
            img = Image.open(img_path)
            face = self.mtcnn.align(img)
            block, la = self.mtcnn.detect_faces(img)
            print(block, la)
            return self.transforms(face).to(self.device).unsqueeze(0)

        def get_embedding(self, img_tensor):
            return self.model(img_tensor)[0]

        def calculate_similarity(self, emb1, emb2):
            return emb1.dot(emb2).item()

    # 使用示例
    recognizer = FaceRecognizer('mtcnn_weights.pth', 'model_ir_se50.pth', device='cpu')

    img1 = recognizer.get_img('./face1.png')
    img2 = recognizer.get_img('./face1.png')
    img3 = recognizer.get_img('./face3.png')

    emb1 = recognizer.get_embedding(img1)
    emb2 = recognizer.get_embedding(img2)
    emb3 = recognizer.get_embedding(img3)

    sim_12 = recognizer.calculate_similarity(emb1, emb2)
    sim_13 = recognizer.calculate_similarity(emb1, emb3)

    print(sim_12)
    print(sim_13)
def get_img(img_path, device):
    img = Image.open(img_path)
    face = mtcnn.align(img)
    block,la = mtcnn.detect_faces(img)
    print(block,la)
    transfroms = Compose(
        [ToTensor(), Normalize([0.5, 0.5, 0.5], [0.5, 0.5, 0.5])])
    return transfroms(face).to(device).unsqueeze(0)


device = 'cpu'
img1 = get_img('./face1.png', device)
img2 = get_img('./face1.png', device)
img3 = get_img('./face3.png', device)

print(img1.shape)

model = Backbone(num_layers=50, drop_ratio=0.6, mode='ir_se')
model.load_state_dict(torch.load('model_ir_se50.pth',map_location=torch.device('cpu')))
model.eval()
model.to(device)

emb1 = model(img1)[0]
emb2 = model(img2)[0]
emb3 = model(img3)[0]
print(emb1.shape)

sim_12 = emb1.dot(emb2).item()
sim_13 = emb1.dot(emb3).item()

print(sim_12)
print(sim_13)

# 512维度的人脸特征向量，考虑使用向量库作为一个对比库
